<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_reviewticker}prestashop>ets_reviewticker_e8faba36acab3b73d6408b3db1ca0961'] = 'Review Ticker';
